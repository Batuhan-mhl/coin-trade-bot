# main.py
from keep_alive import keep_alive
keep_alive()
# Diğer kodlar entegre edilecek