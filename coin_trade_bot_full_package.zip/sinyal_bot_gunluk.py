# sinyal_bot_gunluk.py
def check_signals(): print('Günlük EMA/RSI sinyalleri gönderildi')