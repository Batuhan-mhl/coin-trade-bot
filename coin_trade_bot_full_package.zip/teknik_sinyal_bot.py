# teknik_sinyal_bot.py
def check_signals(): print('Teknik özet görselleri oluşturuldu')