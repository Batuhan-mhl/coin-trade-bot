# gainers_losers.py
def report_gainers_losers(): print('En çok artan/düşen coinler raporlandı')