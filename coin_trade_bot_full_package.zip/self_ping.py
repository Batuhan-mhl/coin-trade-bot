# self_ping.py
import requests, time
URL = 'https://senin-replit-linkin.dev'
def self_ping():
  while True:
    try:
      requests.get(URL)
    except:
      pass
    time.sleep(600)